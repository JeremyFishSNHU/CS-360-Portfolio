package com.example.jeremyfishmodule3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Handles the persistent SQLite database for the Inventory Manager app.
 * The database stores user accounts and inventory information.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 1;

    // User account table
    private static final String TABLE_USERS = "users";
    private static final String USER_ID = "id";
    private static final String USERNAME = "username";
    private static final String PASSWORD = "password";

    // Inventory table
    private static final String TABLE_INVENTORY = "inventory";
    private static final String ITEM_ID = "id";
    private static final String ITEM_NAME = "item_name";
    private static final String ITEM_QUANTITY = "quantity";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Stores usernames and passwords for application login.
        String createUsersTable =
                "CREATE TABLE " + TABLE_USERS + " (" +
                        USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        USERNAME + " TEXT UNIQUE NOT NULL, " +
                        PASSWORD + " TEXT NOT NULL)";

        // Stores all inventory items and their current quantities.
        String createInventoryTable =
                "CREATE TABLE " + TABLE_INVENTORY + " (" +
                        ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        ITEM_NAME + " TEXT NOT NULL, " +
                        ITEM_QUANTITY + " INTEGER NOT NULL)";

        db.execSQL(createUsersTable);
        db.execSQL(createInventoryTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    // ---------------- USER ACCOUNT METHODS ----------------

    /**
     * Creates a new user account.
     * Returns false if the username already exists.
     */
    public boolean addUser(String username, String password) {

        if (userExists(username)) {
            return false;
        }

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(USERNAME, username);
        values.put(PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);

        return result != -1;
    }

    /**
     * Checks the supplied username and password against the database.
     */
    public boolean checkUser(String username, String password) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{USER_ID},
                USERNAME + "=? AND " + PASSWORD + "=?",
                new String[]{username, password},
                null,
                null,
                null
        );

        boolean loginSuccessful = cursor.getCount() > 0;
        cursor.close();

        return loginSuccessful;
    }

    /**
     * Determines whether a username has already been registered.
     */
    public boolean userExists(String username) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{USER_ID},
                USERNAME + "=?",
                new String[]{username},
                null,
                null,
                null
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();

        return exists;
    }

    // ---------------- INVENTORY METHODS ----------------

    /**
     * Adds a new inventory item.
     */
    public boolean addInventoryItem(String itemName, int quantity) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ITEM_NAME, itemName);
        values.put(ITEM_QUANTITY, quantity);

        long result = db.insert(TABLE_INVENTORY, null, values);

        return result != -1;
    }

    /**
     * Returns all inventory records so they can be displayed in the grid.
     */
    public Cursor getAllInventoryItems() {

        SQLiteDatabase db = getReadableDatabase();

        return db.query(
                TABLE_INVENTORY,
                null,
                null,
                null,
                null,
                null,
                ITEM_ID + " ASC"
        );
    }

    /**
     * Updates an existing inventory item's name and quantity.
     */
    public boolean updateInventoryItem(
            int id,
            String itemName,
            int quantity) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ITEM_NAME, itemName);
        values.put(ITEM_QUANTITY, quantity);

        int rowsUpdated = db.update(
                TABLE_INVENTORY,
                values,
                ITEM_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return rowsUpdated > 0;
    }

    /**
     * Updates only the quantity of an inventory item.
     */
    public boolean updateQuantity(int id, int quantity) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ITEM_QUANTITY, quantity);

        int rowsUpdated = db.update(
                TABLE_INVENTORY,
                values,
                ITEM_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return rowsUpdated > 0;
    }

    /**
     * Deletes an inventory item using its database ID.
     */
    public boolean deleteInventoryItem(int id) {

        SQLiteDatabase db = getWritableDatabase();

        int rowsDeleted = db.delete(
                TABLE_INVENTORY,
                ITEM_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return rowsDeleted > 0;
    }
}