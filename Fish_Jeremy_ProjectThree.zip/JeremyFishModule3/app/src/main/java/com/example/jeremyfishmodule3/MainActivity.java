package com.example.jeremyfishmodule3;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.view.ViewGroup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    private EditText editUsername;
    private EditText editPassword;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        databaseHelper = new DatabaseHelper(this);
        showLoginScreen();
    }

    // ---------------- LOGIN SCREEN ----------------

    private void showLoginScreen() {
        setContentView(R.layout.activity_main);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);

        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Check entered credentials against the persistent SQLite database.
        buttonLogin.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(
                        MainActivity.this,
                        "Please enter a username and password",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            if (databaseHelper.checkUser(username, password)) {
                Toast.makeText(
                        MainActivity.this,
                        "Login successful",
                        Toast.LENGTH_SHORT
                ).show();

                showInventoryScreen();
            } else {
                Toast.makeText(
                        MainActivity.this,
                        "Invalid username or password",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        // Allow first-time users to create and save an account.
        buttonCreateAccount.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(
                        MainActivity.this,
                        "Enter a username and password to create an account",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            boolean accountCreated =
                    databaseHelper.addUser(username, password);

            if (accountCreated) {
                Toast.makeText(
                        MainActivity.this,
                        "Account created successfully. You can now log in.",
                        Toast.LENGTH_LONG
                ).show();

                editPassword.setText("");
            } else {
                Toast.makeText(
                        MainActivity.this,
                        "That username already exists",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }


    // ---------------- INVENTORY SCREEN ----------------

    private void showInventoryScreen() {
        setContentView(R.layout.activity_inventory);

        EditText editItemName = findViewById(R.id.editItemName);
        EditText editQuantity = findViewById(R.id.editQuantity);

        TableLayout inventoryTable = findViewById(R.id.inventoryTable);

        loadInventoryFromDatabase(inventoryTable);

        Button buttonAddItem = findViewById(R.id.buttonAddItem);
        Button buttonNotifications = findViewById(R.id.buttonNotifications);

        buttonAddItem.setOnClickListener(v -> {

            String itemName = editItemName.getText().toString().trim();
            String quantityString = editQuantity.getText().toString().trim();

            if (itemName.isEmpty() || quantityString.isEmpty()) {

                Toast.makeText(
                        MainActivity.this,
                        "Please enter an item name and quantity",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            int quantity;

            try {
                quantity = Integer.parseInt(quantityString);
            } catch (NumberFormatException e) {

                Toast.makeText(
                        MainActivity.this,
                        "Quantity must be a number",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            boolean itemAdded =
                    databaseHelper.addInventoryItem(itemName, quantity);

            if (itemAdded) {

                Toast.makeText(
                        MainActivity.this,
                        itemName + " added to inventory",
                        Toast.LENGTH_SHORT
                ).show();

                editItemName.setText("");
                editQuantity.setText("");

                // Reload the inventory screen so the newly saved
                // database record appears with its correct database ID.
                showInventoryScreen();

            } else {

                Toast.makeText(
                        MainActivity.this,
                        "Unable to add item",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        buttonNotifications.setOnClickListener(v -> showNotificationScreen());
    }

    // ---------------- NOTIFICATION SCREEN ----------------

    private void showNotificationScreen() {
        setContentView(R.layout.activity_notifications);

        Button buttonAllowSms = findViewById(R.id.buttonAllowSms);
        Button buttonDenySms = findViewById(R.id.buttonDenySms);
        Button buttonBackInventory = findViewById(R.id.buttonBackInventory);

        TextView textPermissionStatus =
                findViewById(R.id.textPermissionStatus);

        updatePermissionStatus(textPermissionStatus);

        buttonAllowSms.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(
                    MainActivity.this,
                    Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(
                        MainActivity.this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE
                );

            } else {
                textPermissionStatus.setText(
                        "SMS Permission Status: Permission Already Granted"
                );

                Toast.makeText(
                        MainActivity.this,
                        "SMS notifications are enabled",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        buttonDenySms.setOnClickListener(v -> {
            textPermissionStatus.setText(
                    "SMS Permission Status: Notifications Not Enabled"
            );

            Toast.makeText(
                    MainActivity.this,
                    "SMS notifications will remain disabled",
                    Toast.LENGTH_SHORT
            ).show();
        });

        buttonBackInventory.setOnClickListener(v -> showInventoryScreen());
    }

    private void updatePermissionStatus(TextView statusText) {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            statusText.setText(
                    "SMS Permission Status: Permission Granted"
            );

        } else {
            statusText.setText(
                    "SMS Permission Status: Permission Not Granted"
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode == SMS_PERMISSION_CODE) {

            TextView statusText =
                    findViewById(R.id.textPermissionStatus);

            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                statusText.setText(
                        "SMS Permission Status: Permission Granted"
                );

                Toast.makeText(
                        this,
                        "SMS permission granted",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                statusText.setText(
                        "SMS Permission Status: Permission Denied"
                );

                Toast.makeText(
                        this,
                        "SMS permission denied",
                        Toast.LENGTH_SHORT
                ).show();
            }
        }
    }
    private void loadInventoryFromDatabase(TableLayout inventoryTable) {
        Cursor cursor = databaseHelper.getAllInventoryItems();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String itemName = cursor.getString(1);
                int quantity = cursor.getInt(2);

                TableRow newRow = new TableRow(this);

                TextView itemText = new TextView(this);
                itemText.setText(itemName);
                itemText.setPadding(12, 16, 12, 16);
                itemText.setLayoutParams(new TableRow.LayoutParams(
                        0,
                        TableRow.LayoutParams.WRAP_CONTENT,
                        2f
                ));

                TextView quantityText = new TextView(this);
                quantityText.setText(String.valueOf(quantity));
                quantityText.setPadding(12, 16, 12, 16);
                quantityText.setLayoutParams(new TableRow.LayoutParams(
                        0,
                        TableRow.LayoutParams.WRAP_CONTENT,
                        1f
                ));

                Button deleteButton = new Button(this);
                deleteButton.setText("DELETE");

                deleteButton.setOnClickListener(v -> {
                    if (databaseHelper.deleteInventoryItem(id)) {
                        inventoryTable.removeView(newRow);
                        Toast.makeText(
                                MainActivity.this,
                                "Item deleted",
                                Toast.LENGTH_SHORT
                        ).show();
                    }
                });

                newRow.addView(itemText);
                newRow.addView(quantityText);
                newRow.addView(deleteButton);

                inventoryTable.addView(newRow);

            } while (cursor.moveToNext());

            cursor.close();
        }
    }

}